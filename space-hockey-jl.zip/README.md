# Final-project-jl

All images form Google images

Pygame needs to be downloaded 

Files needed:

background.jpg;

paddle1.png;

paddle2.png;

puck.png;

Special thanks to: Professor Pogue, the Internet, and those who helped along the way!

I utilized StackOverflow for questions and ideas for basic conceps.

I found some basic information on github but it did not work so I had to debug and make updates to get all the keys to function properly

All rights reserved
Feel free to improve on the code =)
contact me at jeffreyslacca@lewisu.edu

This started as a pong game but evolved to airhockey and was enhanced to have a space theme.
